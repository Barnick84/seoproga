<div class="col-xs-12 col-12">
                                    <h3>Таблица значений всех урлов</h3>
                                    <table class="table table-bordered table-hover">
                                        <tbody><tr class="success table-success">
                                            <th class="text-left col-xs-6" scope="col"></th>
                                            <th class="text-center col-xs-2" scope="col">Среднее значение</th>
                                            <th class="text-center col-xs-2" scope="col">Медиана</th>
                                                                                            <th class="text-center col-xs-2" scope="col">Ваша страница</th>
                                                                                    </tr>
                                        <tr>
                                            <td>Символы с пробелами</td>
                                            <td class="text-center">12835</td>
                                            <td class="text-center">12822</td>
                                                                                            <td class="text-center" style="background-color:lightyellow;">9318</td>
                                                                                    </tr>
                                        <tr>
                                            <td>Символы без пробелов</td>
                                            <td class="text-center">10870</td>
                                            <td class="text-center">10826</td>
                                                                                            <td class="text-center" style="background-color:lightyellow;">7685</td>
                                                                                    </tr>
                                        <tr>
                                            <td>Слова</td>
                                            <td class="text-center">1965</td>
                                            <td class="text-center">1997</td>
                                                                                            <td class="text-center" style="background-color:lightyellow;">1634</td>
                                                                                    </tr>
                                        <tr>
                                            <td>Уникальные слова</td>
                                            <td class="text-center">446</td>
                                            <td class="text-center">411</td>
                                             
                                                <td class="text-center" style="background-color:lightyellow;">358</td>
                                                                                    </tr>
                                        <tr>
                                            <td>"Тошнота"</td>
                                            <td class="text-center">7</td>
                                            <td class="text-center">7</td>
                                             
                                                <td class="text-center" style="background-color:lightyellow;">8</td>
                                                                                    </tr>
                                        <tr>
                                            <td>"Водянистость"</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                             
                                                <td class="text-center" style="background-color:lightyellow;">0</td>
                                                                                    </tr>
                                        <tr>
                                            <td>Качество текста по закону Ципфа</td>
                                            <td class="text-center">46</td>
                                            <td class="text-center">42</td>
                                             
                                                <td class="text-center" style="background-color:lightyellow;">50</td>
                                                                                    </tr>
                                    </tbody></table>
                                </div>

<div class="table-responsive">
                                        <h3>Таблица по каждому</h3>
                                        <table class="table table-bordered" style="table-layout:fixed;">
                                            <tbody><tr class="success table-success">
                                                <th>URL</th>
                                                <th style="width:120px" class="text-center">Символы с пробелами</th>
                                                <th style="width:120px" class="text-center">Символы без пробелов</th>
                                                <th style="width:110px" class="text-center">Слова</th>
                                                <th style="width:120px" class="text-center">Уникальные слова</th>
        <!--										<th style="width:100px" class="text-center">"Тошнота" текста</th>
                                                <th style="width:150px" class="text-center">"Водянистость" текста</th>-->
                                            </tr>
                                                                                                                                        <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982744]" id="checked_content_4982744_" value="0"><input type="checkbox" name="data[checked_content_4982744]" value="1" checked="checked" id="checked_content_4982744" data-id="4982744" class="checked_content">                                                                <label for="checked_content_4982744">
                                                                    https://experience.tripster.ru/experience/Pyatigorsk/10117-kavkaz/                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">3611</td>
                                                    <td class="text-center">3069</td>
                                                    <td class="text-center">543</td>
                                                    <td class="text-center">
                                                        227                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982745]" id="checked_content_4982745_" value="0"><input type="checkbox" name="data[checked_content_4982745]" value="1" checked="checked" id="checked_content_4982745" data-id="4982745" class="checked_content">                                                                <label for="checked_content_4982745">
                                                                    https://kmv-tours.ru/tours/pyatigorsk/additional/cheap                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">9620</td>
                                                    <td class="text-center">8080</td>
                                                    <td class="text-center">1541</td>
                                                    <td class="text-center">
                                                        314                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982746]" id="checked_content_4982746_" value="0"><input type="checkbox" name="data[checked_content_4982746]" value="1" checked="checked" id="checked_content_4982746" data-id="4982746" class="checked_content">                                                                <label for="checked_content_4982746">
                                                                    https://pyatigorsk.larest.ru/jeep-tour-iz-pyatigorska-exctp10.html                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">12337</td>
                                                    <td class="text-center">10434</td>
                                                    <td class="text-center">1904</td>
                                                    <td class="text-center">
                                                        364                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982747]" id="checked_content_4982747_" value="0"><input type="checkbox" name="data[checked_content_4982747]" value="1" checked="checked" id="checked_content_4982747" data-id="4982747" class="checked_content">                                                                <label for="checked_content_4982747">
                                                                    https://kmv-tours.ru/tours/pyatigorsk/tag/dzhip-tury                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">14445</td>
                                                    <td class="text-center">12109</td>
                                                    <td class="text-center">2337</td>
                                                    <td class="text-center">
                                                        458                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982748]" id="checked_content_4982748_" value="0"><input type="checkbox" name="data[checked_content_4982748]" value="1" checked="checked" id="checked_content_4982748" data-id="4982748" class="checked_content">                                                                <label for="checked_content_4982748">
                                                                    https://horosho-tam.ru/rossiya/pyatigorsk/ekskursii/na-avtobuse                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">13306</td>
                                                    <td class="text-center">11217</td>
                                                    <td class="text-center">2090</td>
                                                    <td class="text-center">
                                                        472                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982749]" id="checked_content_4982749_" value="0"><input type="checkbox" name="data[checked_content_4982749]" value="1" checked="checked" id="checked_content_4982749" data-id="4982749" class="checked_content">                                                                <label for="checked_content_4982749">
                                                                    https://pyatigorsk.larest.ru/ekskursii-iz-pyatigorska-full.html                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">15912</td>
                                                    <td class="text-center">13500</td>
                                                    <td class="text-center">2413</td>
                                                    <td class="text-center">
                                                        581                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982750]" id="checked_content_4982750_" value="0"><input type="checkbox" name="data[checked_content_4982750]" value="1" checked="checked" id="checked_content_4982750" data-id="4982750" class="checked_content">                                                                <label for="checked_content_4982750">
                                                                    https://mashuk-tour.ru/type-travel/ekskursiya/                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">5155</td>
                                                    <td class="text-center">4408</td>
                                                    <td class="text-center">748</td>
                                                    <td class="text-center">
                                                        247                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982751]" id="checked_content_4982751_" value="0"><input type="checkbox" name="data[checked_content_4982751]" value="1" checked="checked" id="checked_content_4982751" data-id="4982751" class="checked_content">                                                                <label for="checked_content_4982751">
                                                                    https://www.sputnik8.com/ru/pyatigorsk                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">22817</td>
                                                    <td class="text-center">19374</td>
                                                    <td class="text-center">3444</td>
                                                    <td class="text-center">
                                                        743                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982752]" id="checked_content_4982752_" value="0"><input type="checkbox" name="data[checked_content_4982752]" value="1" checked="checked" id="checked_content_4982752" data-id="4982752" class="checked_content">                                                                <label for="checked_content_4982752">
                                                                    https://ticketstour.ru/ehkskursii/iz-pyatigorska/odnodnevnye                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">6808</td>
                                                    <td class="text-center">5800</td>
                                                    <td class="text-center">1009</td>
                                                    <td class="text-center">
                                                        288                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                   <div class="checkbox checkbox-success">
                                                                <input type="hidden" name="data[checked_content_4982753]" id="checked_content_4982753_" value="0"><input type="checkbox" name="data[checked_content_4982753]" value="1" checked="checked" id="checked_content_4982753" data-id="4982753" class="checked_content">                                                                <label for="checked_content_4982753">
                                                                    https://guidego.ru/pyatigorsk/na_avtobuse/                                                                </label>
                                                            </div>         
                                                                                                            </td>
                                                    <td class="text-center">24337</td>
                                                    <td class="text-center">20713</td>
                                                    <td class="text-center">3625</td>
                                                    <td class="text-center">
                                                        764                                                                                                            </td>
                                                </tr>
                                                                                            <tr style="background-color:lightyellow;">
                                                    <td style="overflow-x: hidden;white-space: nowrap;text-overflow: ellipsis;">
                                                                                                                                                                            https://xn----8sbah0abhgdc2dma0a.xn--p1ai/pyatigorsk/                                                                                                            </td>
                                                    <td class="text-center">9318</td>
                                                    <td class="text-center">7685</td>
                                                    <td class="text-center">1634</td>
                                                    <td class="text-center">
                                                        358                                                                                                            </td>
                                                </tr>
                                                                                    </tbody></table>
                                        <div class=" " id=""><nobr><a href="/seo_analiz_text" id="changeCheckedUrls" class="btn customLoadingText btn-success" data-loading-text="Перезапустить анализ...">Перезапустить анализ</a></nobr></div>                                        <div class="display-none text-danger errorMessage"></div>
                                    </div>
