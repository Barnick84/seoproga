
import pymysql
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Config

def check_users():
    conn = Config.get_mysql_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, username, yandex_token FROM users")
    users = cur.fetchall()
    for user in users:
        print(f"ID: {user['id']}, Username: {user['username']}, Token: '{user['yandex_token']}'")
    conn.close()

if __name__ == "__main__":
    check_users()
