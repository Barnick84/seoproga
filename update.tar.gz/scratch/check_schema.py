
import pymysql
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Config

def check_schema():
    conn = Config.get_mysql_conn()
    cur = conn.cursor()
    cur.execute("DESCRIBE yandex_queries")
    columns = cur.fetchall()
    for col in columns:
        print(f"Field: {col['Field']}, Type: {col['Type']}")
    conn.close()

if __name__ == "__main__":
    check_schema()
