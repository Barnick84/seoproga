
import pymysql
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Config

def check_queries():
    conn = Config.get_mysql_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as count FROM yandex_queries WHERE site_url = 'русский-кавказ.рф'")
    row = cur.fetchone()
    print(f"Total queries for русский-кавказ.рф: {row['count']}")
    
    cur.execute("SELECT query, hits, fetched_at FROM yandex_queries WHERE site_url = 'русский-кавказ.рф' ORDER BY fetched_at DESC LIMIT 5")
    rows = cur.fetchall()
    for r in rows:
        print(f"Query: {r['query']}, Hits: {r['hits']}, Fetched At: {r['fetched_at']}")
    conn.close()

if __name__ == "__main__":
    check_queries()
